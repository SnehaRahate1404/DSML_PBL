import re 
print("hi")